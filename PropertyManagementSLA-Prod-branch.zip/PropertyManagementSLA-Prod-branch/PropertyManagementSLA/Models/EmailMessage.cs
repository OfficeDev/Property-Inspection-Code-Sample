﻿//using Microsoft.Office365.Exchange;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

//namespace SuiteLevelWebApp.Models
//{
//    public class EmailMessage
//    {
//        public ItemBody Body { get; set; }
//        public DateTimeOffset DateTimeReceived { get; set; }
//        public Recipient From { get; set; }
//        public IList<Recipient> ToRecipients { get; set; }
//    }
//}