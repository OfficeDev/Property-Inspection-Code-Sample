﻿using SuiteLevelWebApp.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuiteLevelWebApp.Models
{
    public class PropertyModel
    {
        public PropertyModel() { }

        public List<RoomDTO> GetRoomsById(int id)
        {
            List<RoomDTO> rooms = new List<RoomDTO>();

            RoomDTO room1 = new RoomDTO();
            room1.Id = 1;
            room1.Name = "Bedroom 1";
            room1.PropertyId = 1;

            rooms.Add(room1);

            RoomDTO room2 = new RoomDTO();
            room2.Id = 1;
            room2.Name = "Bedroom 2";
            room2.PropertyId = 1;

            rooms.Add(room2);

            RoomDTO room3 = new RoomDTO();
            room3.Id = 1;
            room3.Name = "Bedroom 3";
            room3.PropertyId = 1;

            rooms.Add(room3);

            RoomDTO room4 = new RoomDTO();
            room4.Id = 1;
            room4.Name = "Kitchen";
            room4.PropertyId = 1;

            rooms.Add(room4);

            RoomDTO room5 = new RoomDTO();
            room5.Id = 1;
            room5.Name = "Bathroom 1";
            room5.PropertyId = 1;

            rooms.Add(room5);

            RoomDTO room6 = new RoomDTO();
            room6.Id = 1;
            room6.Name = "Bathroom 2";
            room6.PropertyId = 1;

            rooms.Add(room6);

            RoomDTO room7 = new RoomDTO();
            room7.Id = 1;
            room7.Name = "Dining Room";
            room7.PropertyId = 1;

            rooms.Add(room7);

            RoomDTO room8 = new RoomDTO();
            room8.Id = 1;
            room8.Name = "Living Room";
            room8.PropertyId = 1;

            rooms.Add(room8);

            return rooms;
        }

        public PropertyDTO GetPropertyById(int id)
        {
            PropertyDTO property = new PropertyDTO();
            property.Id = 1;
            property.Name = "Beaver Creek Resort";
            property.Owner = "Bode Miller";
            property.Address1 = "40 Village Road";
            property.Address2 = "Unit 1";
            property.City = "Avon";
            property.State = "CO";
            property.PostalCode = "81620";
            property.latitude = "39.630988";
            property.longitude = "-106.523649";

            List<InspectionDTO> inspections = new List<InspectionDTO>();

            InspectionDTO inspection1 = new InspectionDTO();
            inspection1.Id = 1;
            inspection1.Inspector = new InspectorDTO()
            {
                Name = "Julia Mancuso",
                Email = "jm@contoso.com",
                AccountName = "jmancuso"
            };
            inspection1.PropertyId = 1;
            inspection1.Date = DateTime.Now;

            inspections.Add(inspection1);

            InspectionDTO inspection2 = new InspectionDTO();
            inspection2.Id = 1;
            inspection2.Inspector = new InspectorDTO()
            {
                Name = "Jimi Hendrix",
                Email = "jh@contoso.com",
                AccountName = "jhendrix"
            }; ;
            inspection2.PropertyId = 1;
            inspection2.Date = DateTime.Now;

            inspections.Add(inspection2);

            InspectionDTO inspection3 = new InspectionDTO();
            inspection3.Id = 1;
            inspection3.Inspector = new InspectorDTO()
            {
                Name = "Geddy Lee",
                Email = "gl@contoso.com",
                AccountName = "glee"
            };
            inspection3.PropertyId = 1;
            inspection3.Date = DateTime.Now;

            inspections.Add(inspection3);

            InspectionDTO inspection4 = new InspectionDTO();
            inspection4.Id = 1;
            inspection4.Inspector = new InspectorDTO()
            {
                Name = "Billy Corgan",
                Email = "bc@contoso.com",
                AccountName = "bcorgan"
            };
            inspection4.PropertyId = 1;
            inspection4.Date = DateTime.Now;

            inspections.Add(inspection4);

            InspectionDTO inspection5 = new InspectionDTO();
            inspection5.Id = 1;
            inspection5.Inspector = new InspectorDTO()
            {
                Name = "Ickey Woods",
                Email = "iw@contoso.com",
                AccountName = "iwoods"
            };
            inspection5.PropertyId = 1;
            inspection5.Date = DateTime.Now;

            inspections.Add(inspection5);

            InspectionDTO inspection6 = new InspectionDTO();
            inspection6.Id = 1;
            inspection6.Inspector = new InspectorDTO()
            {
                Name = "Scott Stevens",
                Email = "ss@contoso.com",
                AccountName = "sstevens"
            };
            inspection6.PropertyId = 1;
            inspection6.Date = DateTime.Now;

            inspections.Add(inspection6);

            InspectionDTO inspection7 = new InspectionDTO();
            inspection7.Id = 1;
            inspection7.Inspector = new InspectorDTO()
            {
                Name = "Barry Larkin",
                Email = "b;@contoso.com",
                AccountName = "blarkin"
            };
            inspection7.PropertyId = 1;
            inspection7.Date = DateTime.Now;

            inspections.Add(inspection7);

            InspectionDTO inspection8 = new InspectionDTO();
            inspection8.Id = 1;
            inspection8.Inspector = new InspectorDTO()
            {
                Name = "Brett Favre",
                Email = "bf@contoso.com",
                AccountName = "bfavre"
            };
            inspection8.PropertyId = 1;
            inspection8.Date = DateTime.Now;

            inspections.Add(inspection8);

            property.Inspections = inspections;

            return property;
        }
    }
}