﻿using SuiteLevelWebApp.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuiteLevelWebApp.Models
{
    public class RoomModel
    {
        public RoomModel() { }

        public RoomDTO GetRoomById(int id)
        {
            RoomDTO room = new RoomDTO();
            room.Id = 1;
            room.Name = "Bedroom";
            room.PropertyId = 1;

            List<InspectionPhotoDTO> inspectionPhotos = new List<InspectionPhotoDTO>();

            InspectionPhotoDTO inspectionPhoto1 = new InspectionPhotoDTO();
            inspectionPhoto1.Name = "Inspection Photo 1";
            inspectionPhoto1.InspectionId = 1;
            inspectionPhoto1.IncidentId = 1;
            inspectionPhoto1.RoomId = 1;

            inspectionPhotos.Add(inspectionPhoto1);

            InspectionPhotoDTO inspectionPhoto2 = new InspectionPhotoDTO();
            inspectionPhoto2.Name = "Inspection Photo 2";
            inspectionPhoto2.InspectionId = 1;
            inspectionPhoto2.IncidentId = null;
            inspectionPhoto2.RoomId = 1;

            inspectionPhotos.Add(inspectionPhoto1);

            room.InspectionPhotos = inspectionPhotos;

            List<RepairPhotoDTO> repairPhotos = new List<RepairPhotoDTO>();

            RepairPhotoDTO repairPhoto1 = new RepairPhotoDTO();
            repairPhoto1.Name = "Repair Photo 1";
            repairPhoto1.InspectionId = 1;
            repairPhoto1.IncidentId = 1;
            repairPhoto1.RoomId = 1;

            repairPhotos.Add(repairPhoto1);

            RepairPhotoDTO repairPhoto2 = new RepairPhotoDTO();
            repairPhoto2.Name = "Repair Photo 2";
            repairPhoto2.InspectionId = 1;
            repairPhoto2.IncidentId = 1;
            repairPhoto2.RoomId = 1;

            repairPhotos.Add(repairPhoto2);

            room.RepairPhotos = repairPhotos;

            IncidentDTO incident = new IncidentDTO();
            incident.Id = 1;
            incident.Name = "Broken Window";
            incident.Date = DateTime.Today;
            incident.IncidentType = "Breakage";
            incident.InspectionId = 1;
            incident.InspectorIncidentComments = "Inspector Incident Comments";
            incident.DispatcherComments = "Dispatcher Comments";
            incident.RepairComments = "Repair Comments";
            incident.Status = "Status";
            incident.PropertyId = 1;
            incident.RoomId = 1;
            incident.RepairPerson = new RepairPersonDTO()
            {
                Name = "Henry Rollins",
                Email = "hr@contoso.com",
                AccountName = "hrollins"
            };

            room.Incident = incident;

            InspectionCommentDTO inspectionComment = new InspectionCommentDTO();
            inspectionComment.InspectionId = 1;
            inspectionComment.Comment = "Inspection comment";
            inspectionComment.RoomId = 1;

            room.InspectionComment = inspectionComment;

            return room;
        }
    }
}