﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuiteLevelWebApp.Models
{
    public class RepairCompletionModel
    {
        public int IncidentId { get; set; }
    }
}