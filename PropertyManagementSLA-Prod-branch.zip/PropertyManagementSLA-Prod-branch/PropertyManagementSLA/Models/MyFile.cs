﻿
namespace SuiteLevelWebApp.Models
{
    public class MyFile
    {
        public string Name { get; set; }
    }
}