﻿using System.Web.Mvc;

namespace SuiteLevelWebApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult IOS()
        {
            return View();
        }

        public ActionResult Walkthrough()
        {
            return View();
        }

        public ActionResult IconAttribution()
        {
            return View();
        }
    }
}