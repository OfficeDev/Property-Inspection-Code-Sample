﻿using SuiteLevelWebApp.Utils;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace SuiteLevelWebApp.Controllers
{
    [Authorize, HandleAdalException]
    public class O365SPListController : Controller
    {
        static readonly string DemoSiteCollectionUrl = ConfigurationManager.AppSettings["DemoSiteCollectionUrl"];        
        
        public async Task<ActionResult> Index()
        {
            var accessToken = await O365Util.GetAccessToken(ServiceResources.DemoSite);
            
            string requestUrl = DemoSiteCollectionUrl + "/_api/Web/Lists/GetByTitle('Pages')/Items?$select=Title";

            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, requestUrl);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/atom+xml"));
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            HttpResponseMessage response = await client.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                string responseString = await response.Content.ReadAsStringAsync();
                return View();
            }
            else
                return Content("Error");
        }   
    }
}