﻿using Microsoft.Office365.SharePoint.CoreServices;
using Microsoft.Office365.SharePoint.FileServices;
using SuiteLevelWebApp.Models;
using SuiteLevelWebApp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace SuiteLevelWebApp.Controllers
{
    [Authorize, HandleAdalException]
    public class MyFilesController : Controller
    {
        // GET: MyFiles
        public async Task<ActionResult> Index()
        {
            var myFiles = new List<MyFile>();

            var serviceEndpointUri = await O365Util.GetServiceEndpointUri(Capabilities.MyFiles);
            //WORKAROUND
            var filesV1Url = serviceEndpointUri.AbsoluteUri.Replace(@"/_api/me", @"/_api/v1.0/me");
            //END:WORKAROUND

            var client = new SharePointClient(new Uri(filesV1Url),
                async () => await O365Util.GetAccessToken(Capabilities.MyFiles));
            
            var filesResult = await client.Files.ExecuteAsync();

            do
            {
                var files = filesResult.CurrentPage.OfType<File>();

                foreach (var file in files)
                {
                    myFiles.Add(new MyFile { Name = file.Name });
                }

                filesResult = await filesResult.GetNextPageAsync();

            } while (filesResult != null);

            return View(myFiles);
        }
    }
}