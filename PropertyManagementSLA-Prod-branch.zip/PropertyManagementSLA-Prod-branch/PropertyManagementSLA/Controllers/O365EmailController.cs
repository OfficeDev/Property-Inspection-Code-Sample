﻿//using Microsoft.Office365.Exchange;
//using SuiteLevelWebApp.Util;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using System.Web.Mvc;

//namespace SuiteLevelWebApp.Controllers
//{
//    [HandleRedirectRequiredException]
//    public class O365EmailController : Controller
//    {
//        public async Task<ActionResult> Create()
//        {
//            // Call the GetExchangeClient method, which will authenticate
//            // the user and create the ExchangeClient object.
//            var client = await O365Util.GetExchangeClient("Mail");

//            var newEmail = new Message();

//            ItemBody emailBody = new ItemBody();
//            emailBody.Content = "Email Body Text";
//            newEmail.Body = emailBody;

//            Recipient sender = new Recipient();
//            sender.Address = "todd@toddbaginski.com";

//            newEmail.From = sender;

//            Recipient recipient = new Recipient();
//            recipient.Address = "todd@toddbaginski.com";
//            newEmail.ToRecipients.Add(recipient);

//            await client.Me.Messages.AddMessageAsync(newEmail);
//            return View(newEmail);
//        }

//        public async Task<ActionResult> Index()
//        {
//            // Call the GetExchangeClient method, which will authenticate
//            // the user and create the ExchangeClient object.
//            var client = await O365Util.GetExchangeClient("Mail");  

//            var myEmail = new List<Message>();

//            // Use the ExchangeClient object to call the Email API.
//            var messageResults = await (from i in client.Me.Inbox.Messages
//                                        //where i.End >= DateTimeOffset.UtcNow
//                                        select i).Take(10).ExecuteAsync();

//            // Order the results by date received.
//            var messages = messageResults.CurrentPage.OrderBy(e => e.DateTimeReceived);

//            // Create a Message object for each message returned
//            // by the API.
//            foreach (Message message in messages)
//            {
//                Message emailMessage = new Message();
//                emailMessage.Body = message.Body;
//                emailMessage.DateTimeReceived = message.DateTimeReceived;
//                emailMessage.From = message.From;
//                emailMessage.ToRecipients = message.ToRecipients;

//                myEmail.Add(emailMessage);
//            }
//            return View(myEmail);
//        }
//    }
//}