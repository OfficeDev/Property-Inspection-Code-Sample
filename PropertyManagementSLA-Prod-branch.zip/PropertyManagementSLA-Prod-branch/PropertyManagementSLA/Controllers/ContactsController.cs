﻿using SuiteLevelWebApp.Models;
using SuiteLevelWebApp.Utils;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace SuiteLevelWebApp.Controllers
{
    [Authorize, HandleAdalException]
    public class ContactsController : Controller
    {
        public async Task<ActionResult> Index()
        {
            var outlookClient = await O365Util.GetOutlookClient(Capabilities.Contacts);

            var myContacts = new List<MyContact>();
            var contactsResult = await outlookClient.Me.Contacts.ExecuteAsync();
            do
            {
                var contacts = contactsResult.CurrentPage;  
                foreach (var contact in contacts)
                    myContacts.Add(new MyContact { Name = contact.DisplayName });
                contactsResult = await contactsResult.GetNextPageAsync();
            } while (contactsResult != null);
            return View(myContacts);
        }
    }
}