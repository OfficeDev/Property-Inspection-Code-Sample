﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuiteLevelWebApp.Utils
{
    [Flags]
    public enum Capabilities
    {
        Mail = 1,
        Calendar = 2,
        Contacts = 4,
        MyFiles = 8
    }
    
}