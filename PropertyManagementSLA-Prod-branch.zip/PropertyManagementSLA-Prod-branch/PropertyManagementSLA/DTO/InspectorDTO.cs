﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuiteLevelWebApp.DTO
{
    public class InspectorDTO
    {
        public InspectorDTO() { }

        public string Name { get; set; }
        public string AccountName { get; set; }
        public string Email { get; set; }    
    }
}