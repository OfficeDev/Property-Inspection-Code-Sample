﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuiteLevelWebApp.DTO
{
    public class RepairPersonDTO
    {
        public RepairPersonDTO() { }

        public string Name { get; set; }
        public string AccountName { get; set; }
        public string Email { get; set; }      
    }
}