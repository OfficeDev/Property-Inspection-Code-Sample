﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuiteLevelWebApp.DTO
{
    public class RepairPhotoDTO
    {
        public RepairPhotoDTO() { }

        public string Name { get; set; }
        public int InspectionId { get; set; }
        public int RoomId { get; set; }
        public int IncidentId { get; set; }
    }
}